This directory is for extra unit style tests following the structure of
clang/tests, but which are not portable or not suitable for inclusion in the
regular test suite.
